package com.paolorusso.Servizio8080.Servizio8080;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Servizio8080ApplicationTests {

	@Test
	void contextLoads() {
	}

}
