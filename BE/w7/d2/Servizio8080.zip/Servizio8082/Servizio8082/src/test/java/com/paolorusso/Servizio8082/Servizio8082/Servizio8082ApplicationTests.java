package com.paolorusso.Servizio8082.Servizio8082;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Servizio8082ApplicationTests {

	@Test
	void contextLoads() {
	}

}
