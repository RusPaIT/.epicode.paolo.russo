package com.paolorusso.Servizio8080.Servizio8080;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Servizio8080Application {

	public static void main(String[] args) {
		SpringApplication.run(Servizio8080Application.class, args);
	}

}
